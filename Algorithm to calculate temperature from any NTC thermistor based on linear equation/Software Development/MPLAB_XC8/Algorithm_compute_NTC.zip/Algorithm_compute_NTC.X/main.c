/****************************<<<<Introduction>>>>>******************************
 * Project Name    : Algorithm_NTC_read
 * Author          : Raihan Bin Mofidul
 * Selected MCU    : PIC16F1708
 * Compiler        : xc8 v2.31
 * Checksum        : 
 * Date            : 28-DEC-2020
 ******************************************************************************/

/*****************************<<<<<UPDATES>>>>>>********************************
 * @28-DEC-2019: LCD Library is included            
 ******************************************************************************/



/*******************************************************************************
 **********************<<<<Headers & Definitions>>>>>***************************
 ******************************************************************************/
#include "mcc_generated_files/mcc.h"
#include "lcd_library_files/lcd.h"


/*******************************************************************************
 ***************************<<<<Global Variables>>>>>***************************
 ******************************************************************************/
static const uint8_t u8_seg[] = {
    48, //ascii value to display the number 0
    49, //ascii value to display the number 1
    50, //ascii value to display the number 2
    51, //ascii value to display the number 3
    52, //ascii value to display the number 4
    53, //ascii value to display the number 5
    54, //ascii value to display the number 6
    55, //ascii value to display the number 7
    56, //ascii value to display the number 8
    57, //ascii value to display the number 9     
    45, //ascii value to display the symbol '-' @serial 10 
    32, //ascii value to display the symbol ' ' @serial 11
    46, //ascii value to display the symbol '.' @serial 12
};
uint8_t u8_SENSOR_Error;
uint16_t u16_ADC_value, u16_NTC_res;
uint32_t u32_Mn, u32_Cn;
int16_t u16_ADCsample_COUNT, i16_SENSOR_TEMPERATURE_10xDEG;
int32_t i32_SENSOR_ADCsample;

/*******************************************************************************
 * Function Name      : void LCD_Message(uint8_t x) 
 * Returns            : None
 * Arguments          : x
 * Description        : LCD Messages
 * Modification Date  : 03-DEC-2019
 ******************************************************************************/
void LCD_Message(uint8_t x) {
    switch (x) {
        case 0:
            /*********Line-1********/
            LCDGoto(0, 0);
            LCDPutStr("******WRND-001******\0");

            /*********Line-3********/
            LCDGoto(20, 0);
            LCDPutStr("TEMP. DRECTLY FROM  \0");

            /*********Line-2********/
            LCDGoto(0, 1);
            LCDPutStr("ALGORITM TO COMPUTE \0");

            /*********Line-4********/
            LCDGoto(20, 1);
            LCDPutStr("ADC BY L-EQUATION.  \0");

            /*****Optimization******/
            __delay_ms(1000);
            DisplayClr();
            break;
        case 1:
            /*********Line-1********/
            LCDGoto(0, 0);
            LCDPutStr(" DEVELOPED BY       \0");

            /*********Line-3********/
            LCDGoto(20, 0);
            LCDPutStr(" ELECTRONICS ENGR.  \0");

            /*********Line-2********/
            LCDGoto(0, 1);
            LCDPutStr(" RAIHAN BIN MOFIDUL \0");

            /*********Line-4********/
            LCDGoto(20, 1);
            LCDPutStr(" EED, FR&D, WHIL    \0");

            /*****Optimization******/
            __delay_ms(1000);
            DisplayClr();
            break;
        case 2:
            /*********Line-1********/
            LCDGoto(0, 0); //Title
            LCDPutStr("----->MONITOR_<-----\0");

            /*********Line-3********/
            LCDGoto(20, 0); //Title
            LCDPutStr("NTC = \0");
            LCDGoto(26, 0); //First Value
            LCDPutChar(u8_seg[u16_NTC_res / 10000]);
            LCDGoto(27, 0); //Second Value
            LCDPutChar(u8_seg[(u16_NTC_res % 10000) / 1000]);
            LCDGoto(28, 0); //Third Value
            LCDPutChar(u8_seg[((u16_NTC_res / 10) / 10) % 10]);
            LCDGoto(29, 0); //Dot
            LCDPutChar(u8_seg[12]);
            LCDGoto(30, 0); //Fourth Value
            LCDPutChar(u8_seg[(u16_NTC_res / 10) % 10]);
            LCDGoto(31, 0); //Fifth Value
            LCDPutChar(u8_seg[u16_NTC_res % 10]);
            LCDGoto(32, 0); //Unit
            LCDPutStr("    KOhm\0");

            /*********Line-2********/
            LCDGoto(0, 1); //Title
            LCDPutStr("ADC = \0");
            LCDGoto(6, 1); //First Value
            LCDPutChar(u8_seg[u16_ADC_value / 1000]);
            LCDGoto(7, 1); //Second Value
            LCDPutChar(u8_seg[(u16_ADC_value % 1000) / 100]);
            LCDGoto(8, 1); //Third Value
            LCDPutChar(u8_seg[(u16_ADC_value / 10) % 10]);
            LCDGoto(9, 1); //Fourth Value
            LCDPutChar(u8_seg[u16_ADC_value % 10]);
            LCDGoto(10, 1); //Fourth Value
            LCDPutStr("     Value\0");

            /*********Line-4********/
            LCDGoto(20, 1); //Line=4
            LCDPutStr("TEMP= \0");
            if (!u8_SENSOR_Error) {
                /*WHEN, SENSOR TEMPERATURE is NEGATIVE*/
                if (i16_SENSOR_TEMPERATURE_10xDEG <= 0) {
                    LCDGoto(26, 1); //First Value
                    LCDPutChar(u8_seg[10]);
                    LCDGoto(27, 1); //Second Value
                    LCDPutChar(u8_seg[(uint8_t) (i16_SENSOR_TEMPERATURE_10xDEG*-1 / 100)]);
                    LCDGoto(28, 1); //Third Value
                    LCDPutChar(u8_seg[(uint8_t) (i16_SENSOR_TEMPERATURE_10xDEG*-1 / 10) % 10]);
                    LCDGoto(29, 1); //Dot
                    LCDPutChar(u8_seg[12]);
                    LCDGoto(30, 1); //Fourth Value
                    LCDPutChar(u8_seg[(uint8_t) (i16_SENSOR_TEMPERATURE_10xDEG*-1 % 10)]);
                }
                /*WHEN, SENSOR TEMPERATURE IS POSITIVE*/
                else {
                    LCDGoto(26, 1); //First Value
                    LCDPutChar(u8_seg[(uint8_t) (i16_SENSOR_TEMPERATURE_10xDEG / 1000)]);
                    LCDGoto(27, 1); //Second Value
                    LCDPutChar(u8_seg[(uint8_t) (i16_SENSOR_TEMPERATURE_10xDEG % 1000) / 100]);
                    LCDGoto(28, 1); //Third Value
                    LCDPutChar(u8_seg[(uint8_t) (i16_SENSOR_TEMPERATURE_10xDEG / 10) % 10]);
                    LCDGoto(29, 1); //Dot
                    LCDPutChar(u8_seg[12]);
                    LCDGoto(30, 1); //Fourth Value
                    LCDPutChar(u8_seg[(uint8_t) (i16_SENSOR_TEMPERATURE_10xDEG % 10)]);
                }
                LCDGoto(31, 0); //Unit
                LCDPutStr("  DegreeC\0");
            } else {
                LCDGoto(26, 1);
                LCDPutStr("Sensor Damaged\0");
            }
            /*****Optimization******/
            break;
    }
}

/*******************************************************************************
 * Function Name      : void v_30us_ISR (void)
 * Returns            : None
 * Arguments          : None
 * Description        : 30 micro-second Interrupt Service Routine using timer0
 * Modification Date  : 30-DEC-2019
 ******************************************************************************/
void v_30us_ISR(void) {
    if (u16_ADCsample_COUNT < 1024) {
        i32_SENSOR_ADCsample += (int32_t) ADC_GetConversion(NTC_Sensor);
        u16_ADCsample_COUNT++;
    }
}

/*******************************************************************************
 * Function Name      : void v_get_slope_intercept (uint16_t u16_adc)
 * Returns            : u32_Mn & u32_Cn as Global
 * Arguments          : u16_adc
 * Description        : Get Slope & Intercept value from Mapping
 *                      of Polo_10k3950 NTC sensor
 * Modification Date  : 04-Jul-2019
 ******************************************************************************/
void v_get_slope_intercept(uint16_t u16_adc) {
    if (u16_adc) {
        if (u16_adc > 967) { //-40 to -30
            u32_Mn = 4064;
            u32_Cn = 3634688;
        } else if (u16_adc > 928) { //-30 to -20
            u32_Mn = 2503;
            u32_Cn = 2121523;
        } else if (u16_adc > 867) { //-20 to -10
            u32_Mn = 1672;
            u32_Cn = 1350451;
        } else if (u16_adc > 784) { //-10 to 0
            u32_Mn = 1227;
            u32_Cn = 963461;
        } else if (u16_adc > 681) { //0 to 10
            u32_Mn = 998;
            u32_Cn = 783544;
        } else if (u16_adc > 568) { //10 to 20
            u32_Mn = 905;
            u32_Cn = 719657;
        } else if (u16_adc > 456) { //20 to 30
            u32_Mn = 912;
            u32_Cn = 723139;
        } else if (u16_adc > 355) { //30 to 40
            u32_Mn = 1010;
            u32_Cn = 767048;
        } else if (u16_adc > 270) { //40 to 50
            u32_Mn = 1205;
            u32_Cn = 835963;
        } else if (u16_adc > 203) { //50 to 60
            u32_Mn = 1521;
            u32_Cn = 920842;
        } else if (u16_adc > 151) { //60 to 70
            u32_Mn = 1991;
            u32_Cn = 1016177;
        } else if (u16_adc > 112) { //70 to 80
            u32_Mn = 2668;
            u32_Cn = 1118515;
        } else if (u16_adc > 84) { //80 to 90
            u32_Mn = 3616;
            u32_Cn = 1225933;
        } else if (u16_adc > 64) { //90 to 100
            u32_Mn = 4922;
            u32_Cn = 1336730;
        } else if (u16_adc > 37) { //100 to 110
            u32_Mn = 6693;
            u32_Cn = 1450189;
        } else if (u16_adc > 29) { //110 to 120
            u32_Mn = 9061;
            u32_Cn = 1565696;
        }
    }
}

/*******************************************************************************
 * Function Name      : void main (void)
 * Returns            : None
 * Arguments          : None
 * Description        : Main Function (@ SYSTEM CLOCK 32MHz)
 * Modification Date  : 28-DEC-2020
 ******************************************************************************/
void main(void) {
    SYSTEM_Initialize(); // initialize the device   
    INTERRUPT_GlobalInterruptEnable(); // Enable the Global Interrupts  
    INTERRUPT_PeripheralInterruptEnable(); // Enable the Peripheral Interrupts

    LCD_Initialize(); //initializes the LCD driver
    TMR0_SetInterruptHandler(v_30us_ISR); //Timer0 as 30us Interrupt Service Routine

    LCD_Message(0);
    LCD_Message(1);

    while (1) {

        /*******30-DEC-2020: AFTER 2^10 DATA COUNTDOWN*************************/
        if (u16_ADCsample_COUNT == 1024) {
            /***********************Freezer Sensor*****************************/
            /*AVERAGE VALUE OF ADCsample***********************/
            i32_SENSOR_ADCsample = i32_SENSOR_ADCsample >> 10;
            u16_ADC_value = (uint16_t) i32_SENSOR_ADCsample;

            /*FINDING SENSOR ERROR*****************************/
            if (i32_SENSOR_ADCsample <= 29 || i32_SENSOR_ADCsample >= 994) {
                u8_SENSOR_Error = 1;
            }
            /*No Sensor Error; Therefore, Temperature Calculation Begins*******/
            else {
                u8_SENSOR_Error = 0;
                v_get_slope_intercept((uint16_t) i32_SENSOR_ADCsample);
                i32_SENSOR_ADCsample = i32_SENSOR_ADCsample * (int32_t) u32_Mn;
                i32_SENSOR_ADCsample = ((int32_t) u32_Cn - i32_SENSOR_ADCsample) >> 10;
                i16_SENSOR_TEMPERATURE_10xDEG = (int16_t) i32_SENSOR_ADCsample;
            }

            /*Re-initialize*/
            u16_ADCsample_COUNT = 0;
            i32_SENSOR_ADCsample = 0;
        }
        /***********************Freezer Sensor*****************************/


        /*************NTC_Resistance_Measure******************/
        u16_NTC_res = ((float) u16_ADC_value * 1000 / (1023 - u16_ADC_value));

        /*************NTC_Resistance_Measure******************/
        LCD_Message(2);
    }
}
/**
 End of File
 */